var searchData=
[
  ['use_5fexfat_5fbitmap_5fcache',['USE_EXFAT_BITMAP_CACHE',['../_sd_fat_config_8h.html#a8d3fca2607182c1ba389dd61c283a3e2',1,'SdFatConfig.h']]],
  ['use_5ffat_5ffile_5fflag_5fcontiguous',['USE_FAT_FILE_FLAG_CONTIGUOUS',['../_sd_fat_config_8h.html#ad42a354208ecb245adfc238266a612e5',1,'SdFatConfig.h']]],
  ['use_5ffcntl_5fh',['USE_FCNTL_H',['../_sd_fat_config_8h.html#ab4b7255422e65730612f1f6af1a26752',1,'SdFatConfig.h']]],
  ['use_5flong_5ffile_5fnames',['USE_LONG_FILE_NAMES',['../_sd_fat_config_8h.html#a2536b194b3b007604a39e8526e108b52',1,'SdFatConfig.h']]],
  ['use_5fmulti_5fsector_5fio',['USE_MULTI_SECTOR_IO',['../_sd_fat_config_8h.html#ae477a983188d4370faff32b07a5cfacb',1,'SdFatConfig.h']]],
  ['use_5fsd_5fcrc',['USE_SD_CRC',['../_sd_fat_config_8h.html#af2e76ffb2fdb830175abf513dd640fdd',1,'SdFatConfig.h']]],
  ['use_5fseparate_5ffat_5fcache',['USE_SEPARATE_FAT_CACHE',['../_sd_fat_config_8h.html#a23f662882413dcb017ebd8107473b8c3',1,'SdFatConfig.h']]],
  ['use_5fsimple_5flittle_5fendian',['USE_SIMPLE_LITTLE_ENDIAN',['../_sd_fat_config_8h.html#a9d4fac424e31b4383a10211f0489d93b',1,'SdFatConfig.h']]]
];
