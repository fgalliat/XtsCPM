var searchData=
[
  ['end',['end',['../class_sdio_card.html#aef8e287f0e2033d4afe5e7051c293334',1,'SdioCard::end()'],['../class_fs_volume.html#acd5a0e50a30334785d75a8c8bfc3e1f9',1,'FsVolume::end()']]],
  ['endl',['endl',['../iostream_8h.html#ab9868f8e151efc1705646437dbb59bb2',1,'iostream.h']]],
  ['eof',['eof',['../classios.html#a7aa5ea2f670d64eb3dcb3b62eddd576c',1,'ios']]],
  ['erase',['erase',['../class_sd_card_interface.html#a6a57c5bced670759b7c278c7a5988fd1',1,'SdCardInterface::erase()'],['../class_sdio_card.html#a03b1cdcf988acbdee91bfa8974be50f9',1,'SdioCard::erase()'],['../class_sd_spi_card.html#a904d56312d7a9cfc8bf33e3ad041c9eb',1,'SdSpiCard::erase()']]],
  ['erasesinglesectorenable',['eraseSingleSectorEnable',['../class_sd_spi_card.html#a1b137a1ab76da21379bc59efeac90e1f',1,'SdSpiCard']]],
  ['error',['error',['../class_sd_spi_card.html#aa12ad53111abcb187d3c6119a3a77592',1,'SdSpiCard']]],
  ['errorcode',['errorCode',['../class_sd_card_interface.html#af83618545960af2f1ceec84927c12fc9',1,'SdCardInterface::errorCode()'],['../class_sdio_card.html#a1d505c4fb461bb7103692054ef6f7f1f',1,'SdioCard::errorCode()'],['../class_sd_spi_card.html#ad14f9be4d9087db44309fdc6597c949e',1,'SdSpiCard::errorCode()']]],
  ['errordata',['errorData',['../class_sd_card_interface.html#ab84d7a9506d49366d8ec105e239ab0e1',1,'SdCardInterface::errorData()'],['../class_sdio_card.html#a9c2da202da95162d2eb694363fbe8654',1,'SdioCard::errorData()'],['../class_sd_spi_card.html#aae2cc2a741646bb2aaabaf0547298de8',1,'SdSpiCard::errorData()']]],
  ['errorhalt',['errorHalt',['../class_sd_base.html#ac9d239810a48c90bd0f3a3e9c4c606a9',1,'SdBase::errorHalt(print_t *pr)'],['../class_sd_base.html#a1691b7a85fc11851a6942de035d73772',1,'SdBase::errorHalt(print_t *pr, const char *msg)'],['../class_sd_base.html#ac530fe041855d994a53d2e1b9c33f22d',1,'SdBase::errorHalt(print_t *pr, const __FlashStringHelper *msg)']]],
  ['errorline',['errorLine',['../class_sdio_card.html#a37e477b39d2a9c874fd338b4f7ef6b0e',1,'SdioCard']]],
  ['errorprint',['errorPrint',['../class_sd_base.html#a22d184b3266ae7cb31ab47b7203e91ac',1,'SdBase::errorPrint(print_t *pr)'],['../class_sd_base.html#a7d119e8ae896cc4caa073e9f54823f3e',1,'SdBase::errorPrint(print_t *pr, char const *msg)'],['../class_sd_base.html#a6793653198ce4c570ae92d2f9436dca9',1,'SdBase::errorPrint(Print *pr, const __FlashStringHelper *msg)']]],
  ['exfatfile',['ExFatFile',['../class_ex_fat_file.html#a3c1303c37cad370b33f0279524c93720',1,'ExFatFile']]],
  ['exists',['exists',['../class_ex_fat_file.html#a22a717ddc6d2004c540c67a14264d9dd',1,'ExFatFile::exists()'],['../class_ex_fat_volume.html#a7fdcdffb720a1cca5cfa73f4cfa281df',1,'ExFatVolume::exists()'],['../class_fat_file.html#a50242f98dea0d4488ce4039a279f2a57',1,'FatFile::exists()'],['../class_fat_volume.html#a21541734ad76f64ea24b9f45e2bd6117',1,'FatVolume::exists()'],['../class_fs_base_file.html#a76aea9766ffeae5454381a0704e62505',1,'FsBaseFile::exists()'],['../class_fs_volume.html#a9bece771399c97b136868f684c2b4496',1,'FsVolume::exists()']]]
];
