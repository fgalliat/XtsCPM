var searchData=
[
  ['hex',['hex',['../classios__base.html#a3608e51eb0a80ea94ddadd5b713a3750',1,'ios_base']]],
  ['hssettings',['hsSettings',['../class_sd_spi_config.html#a08fb8580affc2bbbfd3ebfccbf8c4a7d',1,'SdSpiConfig']]]
];
