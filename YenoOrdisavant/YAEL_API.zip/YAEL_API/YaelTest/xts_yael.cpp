/**
 * Xtase - fgalliat @Sept2019
 * 
 * YAEL routines Impl.
 * 
 * ESP32 working w/ arduino IDE
 * 
 * Additional board url : https://dl.espressif.com/dl/package_esp32_index.json
 * goto Board Manager
 * choose ESP32 by espressif
 * 
 * DOIT ESP32 DEVKIT V1
 * 
 * for TFT-eSPI lib, (now see TFT4inch Settings how-to...)
 * ESP32 + ILI9486 Screen + SDCard + MCP23017 Keyboard decoder
 * // ===== Xtase Settings =====
 * #define TFT_MISO 19
 * #define TFT_MOSI 23
 * #define TFT_SCLK 18
 * #define TFT_CS    5  // Chip select control pin
 * #define TFT_DC   15  // Data Command control pin
 * #define TFT_RST  -1  // Set TFT_RST to -1 if display RESET is connected to ESP32 board RST
 * 
 * #define SD_CS     4  // SdCard CHIP-SELECT
 * #define TS_CS     2  // TouchScreen CHIP-SELECT
 * 
 * 1.3 MB Sktech
 * 320 KB RAM
 *
 * SubMCU Bridge on RX2/TX2 (ProMini 328P 3.3v)
 * 
 * --------------------------
 * part of XtsCPM project
 */

#include "Arduino.h"

#include "xts_yael.h"

// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$



#include <HardwareSerial.h>
//====================================================================================
//                                    MP3 Player
//====================================================================================
HardwareSerial Serial3(1); // use uart3
#define mp3Serial Serial3

#include "xts_yael_dev_dfplayer.h"
SoundCard sndCard( &mp3Serial );

void setupMp3() {
    Serial3.begin(9600, SERIAL_8N1, 26, 14); // pins 26 rxY, 14 txY, 9600 bps, 8 bits no parity 1 stop bit
    sndCard.init();
    delay(500);
    sndCard.volume(25);
}

//====================================================================================
//                                    MCU Bridge
//====================================================================================

// HardwareSerial Serial2(2); // use uart2
// can be TX only ...
// HardwareSerial Serial1(1);
// Serial1.begin(9600, SERIAL_7E1, 12, -1, true); ....


void cleanBridge() {
    while( Serial2.available() ) {
        Serial2.read();
    }
}

// forward symbol
void cleanKeyb();
void led(bool state);

void setupBridge() {
    // Serial2.begin(9600, SERIAL_8N1, 16, 17); // pins 16 rx2, 17 tx2, 9600 bps, 8 bits no parity 1 stop bit
    Serial2.begin(9600);
    cleanBridge();
    led(true);
    cleanKeyb();
    led(false);
}

//====================================================================================
//                                    Led
//====================================================================================

void led(bool state) {
    if ( state ) { Serial2.write('L'); }
    else  { Serial2.write('l'); }
    delay(1);
}

void drive_led(bool state) {
    led(state);
}

//====================================================================================
//                                    Keyboard
//====================================================================================

#define KB_BUFF_LEN 20
char keyBuff[KB_BUFF_LEN + 1];
bool firstKeyUse = true;

long lastKeyTime = millis();

void cleanKeyb() {
    Serial2.write((uint8_t)'K');
    delay(2);
}

char pollKeyb() {

    if ( firstKeyUse ) {
        firstKeyUse = false;
        memset(keyBuff, 0x00, KB_BUFF_LEN+1);
    }

    int tlen = strlen( keyBuff );
    if ( tlen == 0 && ( millis() - lastKeyTime > 60 ) ) {
      Serial2.write( (uint8_t)'k');  
      delay(4);
      lastKeyTime = millis();
    } 
    
    if ( tlen < KB_BUFF_LEN ) {
        while( Serial2.available() ) {
            keyBuff[ tlen++ ] = (char)Serial2.read();
            if ( tlen >= KB_BUFF_LEN ) {
                break;
            }
        }
        keyBuff[ tlen ] = 0x00;
    }

    char customKey = 0x00;

    if ( tlen > 0 ) {
        customKey = keyBuff[0];

        // memmove ....
        for(int i=1; i < tlen; i++) {
            keyBuff[i-1] = keyBuff[i];
        }
        keyBuff[ tlen-1 ] = 0x00;
        keyBuff[ tlen ] = 0x00;
    }

return customKey;
}

//====================================================================================
//                                    LCD 20x4
//====================================================================================

void lcd_clear() {
    Serial2.write( (uint8_t)'C' );

    delay(2);
}

void lcd_setCursor(int col, int row) {
    Serial2.write( (uint8_t)'c' );
    Serial2.write( (uint8_t)col );
    Serial2.write( (uint8_t)row );
    delay(2);
}

void lcd_home() {
    lcd_setCursor(0,0);
    delay(2);
}

void lcd_print(char* str) {
    Serial2.write( (uint8_t)'P' );
    Serial2.print( str );
    Serial2.write( (uint8_t)'\n' );
    delay(2);
}

//====================================================================================
//                                  Libraries
//====================================================================================

#include "FS.h"
#include "SD.h"
#include "SPI.h"

// Call up the TFT library
#include <TFT_eSPI.h> // Hardware-specific library for ESP8266

// Invoke TFT library this will set the TFT chip select high
TFT_eSPI tft = TFT_eSPI();

#include "xts_yael_soft_drawBMP.h"
#include "xts_yael_soft_drawPAK.h"

// ==== Wiring =====
#define OWN_SPI_CS   5
#define OWN_SPI_DC   15
#define OWN_SPI_MOSI 23
#define OWN_SPI_CLK  18
#define OWN_SPI_MISO 19

#define TFT_CS OWN_SPI_CS
#define SD_CS 4 // SD chip select

bool Y_setup()
{
  // Serial.begin(115200); // Used for messages and the C array generator
  Serial.begin(9600); // Used for messages and the C array generator

  setupBridge();

  lcd_print("Init MP3\n");
  setupMp3();

  // Initialise the SD library before the TFT so the chip select gets set
  lcd_print("Init SD\n");
  if (!SD.begin(SD_CS)) {
    Serial.println("Initialisation failed!");
    lcd_print("! SD failed !");
    return false;
  }
  Serial.println("\r\nInitialisation done.");

  // Now initialise the TFT
  lcd_print("Init TFT\n");
  tft.begin();
  tft.setRotation(DEFAULT_TFT_ROTATION);  // 0 & 2 Portrait. 1 & 3 landscape
  tft.fillScreen(TFT_BLACK);

  // aux screen
  lcd_setCursor(0,0);
  lcd_print("== Xtase @Aug2019 ==");
  lcd_setCursor(0,1);
  //         12345678901234567890
  lcd_print("OrdiSavant new YATL");
  lcd_setCursor(0,2);
  lcd_print("Layout...");
  lcd_setCursor(0,3);
  lcd_print("Have fun !");

return true;
}

// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
// $$ YAEL API

bool yael_setup() { return Y_setup(); }

void yael_tft_cls() { tft.fillScreen(TFT_BLACK); }
void yael_tft_setCursor(int col, int row) { tft.setCursor(col,row); }
void yael_tft_print(char ch) { tft.print(ch); }
void yael_tft_print(char* str) { tft.print(str); }
void yael_tft_println(char* str) { tft.println(str); }
void yael_tft_drawBMP(char* filename, int x, int y) { 
    tft.setRotation(DEFAULT_TFT_ROTATION == 1 ? 2 : 0);
    drawBmp(filename, x, y);
    tft.setRotation(DEFAULT_TFT_ROTATION);
}
void yael_tft_drawPAK(char* filename, int x, int y, int imgNum) { drawImgFromPAK(filename, x, y, imgNum); }

void yael_lcd_cls() { lcd_clear(); }
void yael_lcd_setCursor(int col, int row) { lcd_setCursor(col,row); }
void yael_lcd_print(char* str) { lcd_print(str); }

void yael_mp3Play(int trackNum) { sndCard.play(trackNum); }
void yael_mp3Loop(int trackNum) { yael_lcd_print( (char*)"(!!) MP3 LOOP NYI" ); }
void yael_mp3Vol(int volume) { sndCard.volume( volume ); }
void yael_mp3Pause() { sndCard.pause(); }
void yael_mp3Stop() { sndCard.stop(); }
void yael_mp3Next() { sndCard.next(); }
void yael_mp3Prev() { sndCard.prev(); }
bool yael_mp3IsPlaying() { return sndCard.isPlaying(); }

void yael_led(bool state) { led(state); }

char yael_keyb_poll() { return pollKeyb(); }